#$ delay 30 s
print "Hello world!"